namespace SayiyiYaziyaDondur
{
    using System;
    using System.Drawing;
    using System.Windows.Forms;

   
        public partial class Form1 : Form
        {
            private TextBox txtSayi;
            private Label lblYazi;

            public Form1()
            {
                InitializeComponent();
                StartPosition = FormStartPosition.CenterScreen;
                Text = "Say�y� Yaz�ya D�n��t�r";
                Width = 750;
                Height = 500;

               
            }

            private void Form1_Load(object sender, EventArgs e)
            {
            // "Say�y� Giriniz" label'�
            var lblSayiGiriniz = new Label
                {
                    Text = "Say�y� Giriniz:",
                    Font = new Font("Arial", 10),
                    Location = new Point(80, 80),
                    Width = 150,
                    Height = 40
                };
                Controls.Add(lblSayiGiriniz);

                // Say�n�n girilece�i TextBox
                txtSayi = new TextBox
                {
                    Location = new Point(250, 80),
                    Width = 150,
                    Height = 30
                };
                Controls.Add(txtSayi);

                // "Bu Say�n�n Yaz�l���" label'�
                var lblYazilisi = new Label
                {
                    Text = "Say�n�n Yaz�l���:",
                    Font = new Font("Arial", 10),
                    Location = new Point(80, 175),
                    Width = 170,
                    Height = 40
                };
                Controls.Add(lblYazilisi);

                // Say�n�n yaz�yla g�sterilece�i Label
                lblYazi = new Label
                {
                    Text = "",
                    Font = new Font("Arial", 10),
                    Location = new Point(250, 165),
                    Width = 350,
                    Height = 30,
                    BorderStyle = BorderStyle.Fixed3D,
                    BackColor = SystemColors.Window

                };
                Controls.Add(lblYazi);

                // "Hesapla" butonu
                var btnHesapla = new Button
                {
                    Text = "Hesapla",
                    Left = 250,
                    Top = 250,
                    Width = 150,
                    Height = 40,
                    BackColor = Color.White
                };
                btnHesapla.Click += btnHesapla_Click;
                Controls.Add(btnHesapla);

                // Enter tu�una bas�ld���nda formun kapanmas�
                KeyPreview = true;
                KeyDown += Form1_KeyDown;
            }

            private void btnHesapla_Click(object sender, EventArgs e)
            {
                string sayiText = txtSayi.Text.Trim();
                int sayi;

                // Girilen de�erin 4 haneli olup olmad���n�n kontrol�
                if (sayiText.Length != 4)
                {
                    MessageBox.Show("L�tfen 4 haneli say� giriniz!");
                    return;
                }

                // Girilen de�erin bir say� olup olmad���n�n kontrol�
                if (!int.TryParse(sayiText, out sayi))
                {
                    MessageBox.Show("L�tfen ge�erli bir say� giriniz!");
                    return;
                }

                // �lk hane 0'dan farkl� m� diye kontrol ediyoruz
                if (sayiText[0] == '0')
                {
                    MessageBox.Show("�lk hane 0'dan farkl� olmal�d�r!");
                    return;
                }

                // Say�y� yaz�ya d�n��t�r�yoruz
                string bir, on, yuz, bin;
                int birler, onlar, yuzler, binler;

                birler = sayi % 10;
                sayi = sayi - birler;
                onlar = sayi % 100;
                sayi = sayi - onlar;
                yuzler = sayi % 1000;
                binler = sayi - yuzler;

                switch (binler)
                {
                    case 1000: bin = " B�N"; break;
                    case 2000: bin = " �K� B�N"; break;
                    case 3000: bin = " �� B�N"; break;
                    case 4000: bin = " D�RT B�N"; break;
                    case 5000: bin = " BE� B�N"; break;
                    case 6000: bin = " ALTI B�N"; break;
                    case 7000: bin = " YED� B�N"; break;
                    case 8000: bin = " SEK�Z B�N"; break;
                    case 9000: bin = " DOKUZ B�N"; break;
                   default: bin = ""; break;
                }

                switch (yuzler)
                {
                    case 100: yuz = " Y�Z"; break;
                    case 200: yuz = " �K� Y�Z"; break;
                    case 300: yuz = " �� Y�Z"; break;
                    case 400: yuz = " D�RT Y�Z"; break;
                    case 500: yuz = " BE� Y�Z"; break;
                    case 600: yuz = " ALTI Y�Z"; break;
                    case 700: yuz = " YED� Y�Z"; break;
                    case 800: yuz = " SEK�Z Y�Z"; break;
                    case 900: yuz = " DOKUZ Y�Z"; break;
                    default: yuz = ""; break;
                }

                switch (onlar)
                {
                    case 10: on = " ON"; break;
                    case 20: on = " Y�RM�"; break;
                    case 30: on = " OTUZ"; break;
                    case 40: on = " KIRK"; break;
                    case 50: on = " ELL�"; break;
                    case 60: on = " ALTMI�"; break;
                    case 70: on = " YETM��"; break;
                    case 80: on = " SEKSEN"; break;
                    case 90: on = " DOKSAN"; break;
                    default: on = ""; break;
                }

                switch (birler)
                {
                    case 1: bir = " B�R"; break;
                    case 2: bir = " �K�"; break;
                    case 3: bir = " ��"; break;
                    case 4: bir = " D�RT"; break;
                    case 5: bir = " BE�"; break;
                    case 6: bir = " ALTI"; break;
                    case 7: bir = " YED�"; break;
                    case 8: bir = " SEK�Z"; break;
                    case 9: bir = " DOKUZ"; break;
                    default: bir = ""; break;
                }

                lblYazi.Text = bin + yuz + on + bir;
            }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            // E�er Enter tu�una bas�ld�ysa formu kapat
            if (e.KeyCode == Keys.Enter)
            {
                Close();
            }
        }
    }
    }
