﻿using System;

public class Yayin
{
    public string yayinAdi;
    public string yayinEvi;
    public int yayinYili;

    public Yayin(string ad, string ev, int yil)
    {
        yayinAdi = ad;
        yayinEvi = ev;
        yayinYili = yil;
    }
}

public class Kitap : Yayin
{
    public string yazarAdi;
    public string ISBNNo;

    public Kitap(string ad, string yazar, string ev, int yil, string isbn) : base(ad, ev, yil)
    {
        yazarAdi = yazar;

        if (isbn.Length == 10)
            ISBNNo = isbn;
        else
            throw new ArgumentException("ISBN 10 haneli olmalıdır.");
    }

    public void Yazdir()
    {
        Console.WriteLine("Kitap Adı: " + yayinAdi);
        Console.WriteLine("Yazar: " + yazarAdi);
        Console.WriteLine("Yayınevi: " + yayinEvi);
        Console.WriteLine("Yayın Yılı: " + yayinYili);
        Console.WriteLine("ISBN: " + ISBNNo);
    }
}

public class Dergi : Yayin
{
    public string Sayi;
    public string ISSNNo;

    public Dergi(string ad, string ev, int yil, string sayi, string issn) : base(ad, ev, yil)
    {
        Sayi = sayi;

        if (issn.Length == 8)
            ISSNNo = issn;
        else
            throw new ArgumentException("ISSN 8 rakamlı olmalıdır.");
    }

    public void Yazdir()
    {
        Console.WriteLine("Dergi Adı: " + yayinAdi);
        Console.WriteLine("Yayınevi: " + yayinEvi);
        Console.WriteLine("Yayın Yılı: " + yayinYili);
        Console.WriteLine("Sayı: " + Sayi);
        Console.WriteLine("ISSN: " + ISSNNo);
    }
}


public class Program
{
    public static void Main(string[] args)
    {
        while (true)
        {
            Console.WriteLine("Bilgi almak istediğiniz yayın türünü yazınız: Kitap / Dergi");
            string secim = Console.ReadLine().ToLower();

            if (secim == "kitap")
            {
                Kitap kitap = new Kitap("Atlantis", "David Gibbins", "Altın Kitaplar", 2006, "9759991154");
                kitap.Yazdir();
            }
            else if (secim == "dergi")
            {
                Dergi dergi = new Dergi("J. Software Engineering", "Elsevier", 1999, "9", "14538785");
                dergi.Yazdir();
            }
            else
            {
                Console.WriteLine("Geçersiz seçim yaptınız!");
                
            }

            Console.WriteLine("\nDevam etmek için herhangi bir tuşa basın, programı sonlandırmak için Enter'a basın.");
            if (Console.ReadKey().Key == ConsoleKey.Enter)
                break;

            Console.Clear();
        }
    }
}
